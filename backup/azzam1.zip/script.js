
// Tunggu sampai seluruh struktur HTML selesai dibaca browser.
document.addEventListener("DOMContentLoaded", function () {

    // ================= PENGATURAN ELEMEN =================

    // Mengambil elemen navbar dari halaman HTML.
    const navbar = document.querySelector(".custom-navbar");

    // Mengambil bagian menu yang bisa dibuka atau ditutup di perangkat kecil.
    const navbarCollapse = document.querySelector("#navbarNav");

    // Mengambil seluruh tautan menu navigasi.
    const navLinks = document.querySelectorAll("#navbarNav .nav-link");

    // Mengambil semua bagian halaman yang memiliki ID.
    const sections = document.querySelectorAll("main section[id]");


    // ================= EFEK NAVBAR SAAT SCROLL =================

    // Fungsi untuk mengubah tampilan navbar ketika halaman digulir.
    function updateNavbar() {

        // Jika halaman sudah digulir lebih dari 30 piksel,
        // tambahkan class "scrolled" agar navbar menjadi lebih solid.
        // Jika kembali ke atas, class tersebut akan dihapus.
        navbar.classList.toggle("scrolled", window.scrollY > 30);
    }

    // Periksa posisi halaman saat website pertama kali dibuka.
    updateNavbar();

    // Jalankan fungsi setiap kali posisi scroll berubah.
    window.addEventListener("scroll", updateNavbar, { passive: true });


    // ================= NAVBAR RESPONSIF =================

    // Menutup menu dropdown setelah pengguna memilih menu di ponsel.


    // ================= MENU AKTIF SESUAI BAGIAN HALAMAN =================

    // Amati bagian halaman yang sedang terlihat di layar.
    // Fitur ini menggunakan IntersectionObserver bawaan browser.
    const sectionObserver = new IntersectionObserver(
        function (entries) {

            entries.forEach(function (entry) {

                // Perbarui menu hanya jika bagian tersebut sedang terlihat.
                if (entry.isIntersecting) {

                    // Ambil ID bagian yang sedang diamati.
                    const sectionId = entry.target.id;

                    // Periksa semua tautan navigasi.
                    navLinks.forEach(function (link) {

                        // Cocokkan tujuan tautan dengan ID bagian halaman.
                        const isActive =
                            link.getAttribute("href") === "#" + sectionId;

                        // Tambahkan class active pada menu yang sesuai.
                        link.classList.toggle("active", isActive);

                        // Perbarui atribut aksesibilitas untuk menu aktif.
                        if (isActive) {
                            link.setAttribute("aria-current", "page");
                        } else {
                            link.removeAttribute("aria-current");
                        }
                    });
                }
            });

        },
        {
            // Area pengamatan dipersempit agar pergantian menu lebih alami.
            rootMargin: "-35% 0px -55% 0px",
            threshold: 0
        }
    );

    // Mulai mengamati setiap bagian halaman.
    sections.forEach(function (section) {
        sectionObserver.observe(section);
    });


    // ================= TOMBOL PESAN SEKARANG =================

    // Ambil semua tombol pemesanan pada kartu layanan.
    const serviceButtons = document.querySelectorAll(".service-button");

    // Ambil pilihan layanan pada formulir kontak.
    const pilihanLayanan = document.querySelector("#pilihanLayanan");

    // Ambil bagian kontak untuk tujuan navigasi.
    const bagianKontak = document.querySelector("#kontak");

    // Jalankan fungsi untuk setiap tombol layanan.
    serviceButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            // Baca nama layanan dari atribut data-service pada tombol.
            // Contoh: data-service="Cuci Kering".
            const namaLayanan = button.dataset.service;

            // Pilih layanan yang sesuai di dalam formulir kontak.
            pilihanLayanan.value = namaLayanan;

            // Arahkan pengguna ke bagian kontak secara halus.
            bagianKontak.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        });
    });


    // ================= TAHUN OTOMATIS PADA FOOTER =================

    // Ambil elemen tempat tahun akan ditampilkan.
    const tahunElement = document.querySelector("#tahun");

    // Isi tahun menggunakan waktu dari perangkat pengunjung.
    tahunElement.textContent = new Date().getFullYear();

});